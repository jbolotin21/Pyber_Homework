
# This is PYBER


```python
# Dependencies
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
```


```python
# save file path to variable
city_data = "../raw_data/city_data.csv"

# read with pandas
city_data = pd.read_csv(city_data)
city_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
# save file path to variable
ride_data = "../raw_data/ride_data.csv"

# read with pandas
ride_data = pd.read_csv(ride_data)
ride_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>2016-01-16 13:49:27</td>
      <td>38.35</td>
      <td>5403689035038</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South Roy</td>
      <td>2016-01-02 18:42:34</td>
      <td>17.49</td>
      <td>4036272335942</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wiseborough</td>
      <td>2016-01-21 17:35:29</td>
      <td>44.18</td>
      <td>3645042422587</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Spencertown</td>
      <td>2016-07-31 14:53:22</td>
      <td>6.87</td>
      <td>2242596575892</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nguyenbury</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
    </tr>
  </tbody>
</table>
</div>




```python
# merge tables
combined_pd = pd.merge(city_data, ride_data, on ='city')
combined_pd.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-19 04:27:52</td>
      <td>5.51</td>
      <td>6246006544795</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-04-17 06:59:50</td>
      <td>5.54</td>
      <td>7466473222333</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-05-04 15:06:07</td>
      <td>30.54</td>
      <td>2140501382736</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-01-25 20:44:56</td>
      <td>12.08</td>
      <td>1896987891309</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-09 18:19:47</td>
      <td>17.91</td>
      <td>8784212854829</td>
    </tr>
  </tbody>
</table>
</div>




```python
# group by city
city_group = combined_pd.groupby(by="city")
city_group
```




    <pandas.core.groupby.DataFrameGroupBy object at 0x000001E0316BE160>




```python
# determine types of cities
city_type = city_group['type'].first()
city_type.head()
```




    city
    Alvarezhaven       Urban
    Alyssaberg         Urban
    Anitamouth      Suburban
    Antoniomouth       Urban
    Aprilchester       Urban
    Name: type, dtype: object




```python
# determine avg fares
avg_fares = city_group["fare"].mean()
avg_fares.head()
```




    city
    Alvarezhaven    23.928710
    Alyssaberg      20.609615
    Anitamouth      37.315556
    Antoniomouth    23.625000
    Aprilchester    21.981579
    Name: fare, dtype: float64




```python
# total number of rides per city
num_rides = city_group["ride_id"].count()
num_rides.head()
```




    city
    Alvarezhaven    31
    Alyssaberg      26
    Anitamouth       9
    Antoniomouth    22
    Aprilchester    19
    Name: ride_id, dtype: int64




```python
# number of drivers
num_drivers = (city_group['driver_count'].sum())/(city_group['driver_count'].count())
num_drivers.head()
```




    city
    Alvarezhaven    21.0
    Alyssaberg      67.0
    Anitamouth      16.0
    Antoniomouth    21.0
    Aprilchester    49.0
    Name: driver_count, dtype: float64



### Summary Table Grouped by City


```python
# create summary table
city_summary = pd.DataFrame({"Type": city_type,
                            "Average Fare": avg_fares,
                            "Number of Rides": num_rides,
                            "Number of Drivers": num_drivers})
city_summary.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Fare</th>
      <th>Number of Drivers</th>
      <th>Number of Rides</th>
      <th>Type</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alvarezhaven</th>
      <td>23.928710</td>
      <td>21.0</td>
      <td>31</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>Alyssaberg</th>
      <td>20.609615</td>
      <td>67.0</td>
      <td>26</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>Anitamouth</th>
      <td>37.315556</td>
      <td>16.0</td>
      <td>9</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>Antoniomouth</th>
      <td>23.625000</td>
      <td>21.0</td>
      <td>22</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>Aprilchester</th>
      <td>21.981579</td>
      <td>49.0</td>
      <td>19</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>



## Part One


```python
# set the order of columns
city_summary = city_summary[['Type', 'Number of Drivers', 'Number of Rides', 'Average Fare']]
city_summary.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Type</th>
      <th>Number of Drivers</th>
      <th>Number of Rides</th>
      <th>Average Fare</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alvarezhaven</th>
      <td>Urban</td>
      <td>21.0</td>
      <td>31</td>
      <td>23.928710</td>
    </tr>
    <tr>
      <th>Alyssaberg</th>
      <td>Urban</td>
      <td>67.0</td>
      <td>26</td>
      <td>20.609615</td>
    </tr>
    <tr>
      <th>Anitamouth</th>
      <td>Suburban</td>
      <td>16.0</td>
      <td>9</td>
      <td>37.315556</td>
    </tr>
    <tr>
      <th>Antoniomouth</th>
      <td>Urban</td>
      <td>21.0</td>
      <td>22</td>
      <td>23.625000</td>
    </tr>
    <tr>
      <th>Aprilchester</th>
      <td>Urban</td>
      <td>49.0</td>
      <td>19</td>
      <td>21.981579</td>
    </tr>
  </tbody>
</table>
</div>




```python
#figure out max ranges
num_rides.max()
```




    64




```python
#urban
urban = city_summary.loc[city_summary["Type"]== "Urban"]

#suburban
suburban = city_summary.loc[city_summary["Type"]== "Suburban"]

#rural
rural = city_summary.loc[city_summary["Type"]== "Rural"]
```

## Bubble Plot of Ride Sharing Data


```python
#urban
plt.scatter(urban["Number of Rides"], urban["Average Fare"], color = "lightcoral", edgecolors="black", s = urban["Number of Drivers"]*10, label = "Urban", alpha = 0.5, linewidth = 1)

#Suburban
plt.scatter(suburban["Number of Rides"], suburban["Average Fare"], color = "lightskyblue", edgecolors ="black", s = suburban["Number of Drivers"]*10, label = "Suburban", alpha = 0.5, linewidth = 1)

#Rural
plt.scatter(rural["Number of Rides"], rural["Average Fare"], color = "gold", edgecolors = "black", s = rural["Number of Drivers"]*10, label = "Rural", alpha = 0.5, linewidth = 1)

#Add labels
plt.title("Pyber Ride Sharing Data")
plt.xlabel("Number of Rides (Per City)")
plt.ylabel("Average Fares ($)")

#Add range and color scheme
plt.grid(color='white')
plt.ylim(15, 55)
plt.style.use('seaborn')

#Add a note to the side
plt.text(70, 40,"Note: \nCircle size correlates with driver count per city.")

#Add the legend.
plt.legend(title = "City Type", loc= "upper right")

#Show plot.
plt.show()
```


![png](output_17_0.png)


## Part Two


```python
# group by type
by_type = combined_pd.groupby('type')
by_type.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-19 04:27:52</td>
      <td>5.51</td>
      <td>6246006544795</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-04-17 06:59:50</td>
      <td>5.54</td>
      <td>7466473222333</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-05-04 15:06:07</td>
      <td>30.54</td>
      <td>2140501382736</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-01-25 20:44:56</td>
      <td>12.08</td>
      <td>1896987891309</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-09 18:19:47</td>
      <td>17.91</td>
      <td>8784212854829</td>
    </tr>
    <tr>
      <th>1625</th>
      <td>Carrollbury</td>
      <td>4</td>
      <td>Suburban</td>
      <td>2016-05-09 03:12:10</td>
      <td>25.00</td>
      <td>485795568537</td>
    </tr>
    <tr>
      <th>1626</th>
      <td>Carrollbury</td>
      <td>4</td>
      <td>Suburban</td>
      <td>2016-06-09 05:04:24</td>
      <td>49.47</td>
      <td>617204620844</td>
    </tr>
    <tr>
      <th>1627</th>
      <td>Carrollbury</td>
      <td>4</td>
      <td>Suburban</td>
      <td>2016-05-20 06:12:36</td>
      <td>35.33</td>
      <td>73368831241</td>
    </tr>
    <tr>
      <th>1628</th>
      <td>Carrollbury</td>
      <td>4</td>
      <td>Suburban</td>
      <td>2016-03-21 17:31:26</td>
      <td>20.26</td>
      <td>7948046018548</td>
    </tr>
    <tr>
      <th>1629</th>
      <td>Carrollbury</td>
      <td>4</td>
      <td>Suburban</td>
      <td>2016-08-20 11:20:51</td>
      <td>46.67</td>
      <td>4786094151694</td>
    </tr>
    <tr>
      <th>2282</th>
      <td>South Elizabethmouth</td>
      <td>3</td>
      <td>Rural</td>
      <td>2016-04-03 11:13:07</td>
      <td>22.79</td>
      <td>8193837300497</td>
    </tr>
    <tr>
      <th>2283</th>
      <td>South Elizabethmouth</td>
      <td>3</td>
      <td>Rural</td>
      <td>2016-03-11 12:27:01</td>
      <td>26.72</td>
      <td>4943246873754</td>
    </tr>
    <tr>
      <th>2284</th>
      <td>South Elizabethmouth</td>
      <td>3</td>
      <td>Rural</td>
      <td>2016-11-23 07:47:18</td>
      <td>46.39</td>
      <td>1939838068038</td>
    </tr>
    <tr>
      <th>2285</th>
      <td>South Elizabethmouth</td>
      <td>3</td>
      <td>Rural</td>
      <td>2016-07-19 09:35:59</td>
      <td>31.09</td>
      <td>2959749591417</td>
    </tr>
    <tr>
      <th>2286</th>
      <td>South Elizabethmouth</td>
      <td>3</td>
      <td>Rural</td>
      <td>2016-04-21 10:20:09</td>
      <td>16.50</td>
      <td>5702608059064</td>
    </tr>
  </tbody>
</table>
</div>



## % of Total Fares by City Type


```python
# create table/get data
total_fares = combined_pd['fare'].sum()
percent_fares = (by_type['fare'].sum())/total_fares
percent_fares*100
```




    type
    Rural        6.579786
    Suburban    31.445750
    Urban       61.974463
    Name: fare, dtype: float64




```python
# create labels, designate colors
community = ['Rural', 'Suburban', 'Urban']
percent_community = [6.579786, 31.445750, 61.974463]
colors = ['gold', 'lightskyblue', 'lightcoral']
explode = [.5, 0, 0]

#chart effects
plt.pie(percent_community, explode=explode, labels=community, colors=colors, autopct="%1.1f%%", shadow=True, startangle=150)
plt.axis("equal")

# Set a Title
plt.title("% of Total Rides by City Type")
# Prints our pie chart to the screen
plt.show()
```


![png](output_22_0.png)


## % of Total Rides by City Type


```python
# create table/get data
total_rides = combined_pd['ride_id'].count()
percent_rides = (by_type['ride_id'].count())/total_rides
percent_rides*100
```




    type
    Rural        5.193187
    Suburban    27.295388
    Urban       67.511425
    Name: ride_id, dtype: float64




```python
# create labels, designate colors
community = ['Rural', 'Suburban', 'Urban']
percent_community = [5.193187, 27.295388, 67.511425]
colors = ['gold', 'lightskyblue', 'lightcoral']
explode = [0, 0, 0.2]

#chart effects
plt.pie(percent_community, explode=explode, labels=community, colors=colors, autopct="%1.1f%%", shadow=True, startangle=150)
plt.axis("equal")
# Set a Title
plt.title("% of Total Rides by City Type")
# Prints our pie chart to the screen
plt.show()
```


![png](output_25_0.png)


## % of Total Drivers by City Type


```python
# create table/get data
drivers_by_type = by_type['driver_count'].sum()
total_drivers = drivers_by_type.sum()
percent_drivers = drivers_by_type/total_drivers
percent_drivers*100
```




    type
    Rural        0.969876
    Suburban    12.980602
    Urban       86.049521
    Name: driver_count, dtype: float64




```python
# create labels, designate colors
community = ['Rural', 'Suburban', 'Urban']
percent_community = [.969876, 12.980602, 86.049521]
colors = ['gold', 'lightskyblue', 'lightcoral']
explode = [0, 0.2, 0]

#chart effects
plt.pie(percent_community, explode=explode, labels=community, colors=colors, autopct="%1.1f%%", shadow=True, startangle=150)
plt.axis("equal")
# Set a Title
plt.title("% of Total Drivers by City Type")
# Prints our pie chart to the screen
plt.show()
```


![png](output_28_0.png)

