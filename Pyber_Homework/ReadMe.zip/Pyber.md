
# This is PYBER


```python
# Dependencies
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
```


```python
# save file path to variable
city_data = "../raw_data/city_data.csv"

# read with pandas
city_data = pd.read_csv(city_data)
city_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
# save file path to variable
ride_data = "../raw_data/ride_data.csv"

# read with pandas
ride_data = pd.read_csv(ride_data)
ride_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>2016-01-16 13:49:27</td>
      <td>38.35</td>
      <td>5403689035038</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South Roy</td>
      <td>2016-01-02 18:42:34</td>
      <td>17.49</td>
      <td>4036272335942</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wiseborough</td>
      <td>2016-01-21 17:35:29</td>
      <td>44.18</td>
      <td>3645042422587</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Spencertown</td>
      <td>2016-07-31 14:53:22</td>
      <td>6.87</td>
      <td>2242596575892</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nguyenbury</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
    </tr>
  </tbody>
</table>
</div>




```python
# merge tables
combined_pd = pd.merge(city_data, ride_data, on ='city')
combined_pd.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-19 04:27:52</td>
      <td>5.51</td>
      <td>6246006544795</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-04-17 06:59:50</td>
      <td>5.54</td>
      <td>7466473222333</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-05-04 15:06:07</td>
      <td>30.54</td>
      <td>2140501382736</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-01-25 20:44:56</td>
      <td>12.08</td>
      <td>1896987891309</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-09 18:19:47</td>
      <td>17.91</td>
      <td>8784212854829</td>
    </tr>
  </tbody>
</table>
</div>




```python
# group by city
city_group = combined_pd.groupby(by="city")
city_group
```




    <pandas.core.groupby.DataFrameGroupBy object at 0x000002D2368B5978>




```python
# determine types of cities
city_type = city_group['type'].first()
city_type.head()
```




    city
    Alvarezhaven       Urban
    Alyssaberg         Urban
    Anitamouth      Suburban
    Antoniomouth       Urban
    Aprilchester       Urban
    Name: type, dtype: object




```python
# determine avg fares
avg_fares = city_group["fare"].mean()
avg_fares.head()
```




    city
    Alvarezhaven    23.928710
    Alyssaberg      20.609615
    Anitamouth      37.315556
    Antoniomouth    23.625000
    Aprilchester    21.981579
    Name: fare, dtype: float64




```python
# total number of rides per city
num_rides = city_group["ride_id"].count()
num_rides.head()
```




    city
    Alvarezhaven    31
    Alyssaberg      26
    Anitamouth       9
    Antoniomouth    22
    Aprilchester    19
    Name: ride_id, dtype: int64




```python
# number of drivers
num_drivers = (city_group['driver_count'].sum())/(city_group['driver_count'].count())
num_drivers.head()
```




    city
    Alvarezhaven    21.0
    Alyssaberg      67.0
    Anitamouth      16.0
    Antoniomouth    21.0
    Aprilchester    49.0
    Name: driver_count, dtype: float64



### Summary Table Grouped by City


```python
# create summary table
city_summary = pd.DataFrame({"Type": city_type,
                            "Average Fare": avg_fares,
                            "Number of Rides": num_rides,
                            "Number of Drivers": num_drivers})
city_summary.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average Fare</th>
      <th>Number of Drivers</th>
      <th>Number of Rides</th>
      <th>Type</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alvarezhaven</th>
      <td>23.928710</td>
      <td>21.0</td>
      <td>31</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>Alyssaberg</th>
      <td>20.609615</td>
      <td>67.0</td>
      <td>26</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>Anitamouth</th>
      <td>37.315556</td>
      <td>16.0</td>
      <td>9</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>Antoniomouth</th>
      <td>23.625000</td>
      <td>21.0</td>
      <td>22</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>Aprilchester</th>
      <td>21.981579</td>
      <td>49.0</td>
      <td>19</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>



## Part One


```python
# set the order of columns
city_summary = city_summary[['Type', 'Number of Drivers', 'Number of Rides', 'Average Fare']]
city_summary.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Type</th>
      <th>Number of Drivers</th>
      <th>Number of Rides</th>
      <th>Average Fare</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alvarezhaven</th>
      <td>Urban</td>
      <td>21.0</td>
      <td>31</td>
      <td>23.928710</td>
    </tr>
    <tr>
      <th>Alyssaberg</th>
      <td>Urban</td>
      <td>67.0</td>
      <td>26</td>
      <td>20.609615</td>
    </tr>
    <tr>
      <th>Anitamouth</th>
      <td>Suburban</td>
      <td>16.0</td>
      <td>9</td>
      <td>37.315556</td>
    </tr>
    <tr>
      <th>Antoniomouth</th>
      <td>Urban</td>
      <td>21.0</td>
      <td>22</td>
      <td>23.625000</td>
    </tr>
    <tr>
      <th>Aprilchester</th>
      <td>Urban</td>
      <td>49.0</td>
      <td>19</td>
      <td>21.981579</td>
    </tr>
  </tbody>
</table>
</div>




```python
#figure out max ranges
num_rides.max()
```




    64




```python
#urban
urban = city_summary.loc[city_summary["Type"]== "Urban"]

#suburban
suburban = city_summary.loc[city_summary["Type"]== "Suburban"]

#rural
rural = city_summary.loc[city_summary["Type"]== "Rural"]
```

## Bubble Plot of Ride Sharing Data


```python
#urban
plt.scatter(urban["Number of Rides"], urban["Average Fare"], color = "lightcoral", edgecolors="black", s = urban["Number of Drivers"]*10, label = "Urban", alpha = 0.5, linewidth = 1)

#Suburban
plt.scatter(suburban["Number of Rides"], suburban["Average Fare"], color = "lightskyblue", edgecolors ="black", s = suburban["Number of Drivers"]*10, label = "Suburban", alpha = 0.5, linewidth = 1)

#Rural
plt.scatter(rural["Number of Rides"], rural["Average Fare"], color = "gold", edgecolors = "black", s = rural["Number of Drivers"]*10, label = "Rural", alpha = 0.5, linewidth = 1)

#Add labels
plt.title("Pyber Ride Sharing Data")
plt.xlabel("Number of Rides (Per City)")
plt.ylabel("Average Fares ($)")

#Add range and color scheme
plt.grid(color='white')
plt.ylim(15, 55)
plt.style.use('seaborn')

#Add a note to the side
plt.text(70, 40,"Note: \nCircle size correlates with driver count per city.")

#Add the legend.
plt.legend(title = "City Type", loc= "upper right")

#Show plot.
plt.show()
```


![png](output_17_0.png)


## Part Two


```python
# group by city
by_city = combined_pd.groupby('city')
by_city.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-19 04:27:52</td>
      <td>5.51</td>
      <td>6246006544795</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-04-17 06:59:50</td>
      <td>5.54</td>
      <td>7466473222333</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-05-04 15:06:07</td>
      <td>30.54</td>
      <td>2140501382736</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-01-25 20:44:56</td>
      <td>12.08</td>
      <td>1896987891309</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-09 18:19:47</td>
      <td>17.91</td>
      <td>8784212854829</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
      <td>2016-11-08 19:22:04</td>
      <td>19.49</td>
      <td>1702803950740</td>
    </tr>
    <tr>
      <th>30</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
      <td>2016-03-19 13:08:09</td>
      <td>35.07</td>
      <td>9198401002936</td>
    </tr>
    <tr>
      <th>31</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
      <td>2016-05-12 15:57:15</td>
      <td>41.63</td>
      <td>224683791660</td>
    </tr>
    <tr>
      <th>32</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
      <td>2016-04-07 06:59:51</td>
      <td>19.01</td>
      <td>4648481871830</td>
    </tr>
    <tr>
      <th>54</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
      <td>2016-10-01 19:07:00</td>
      <td>16.36</td>
      <td>8450340983211</td>
    </tr>
    <tr>
      <th>55</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
      <td>2016-07-19 07:42:04</td>
      <td>11.24</td>
      <td>8566233760392</td>
    </tr>
    <tr>
      <th>56</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
      <td>2016-09-20 02:40:41</td>
      <td>23.26</td>
      <td>825335145222</td>
    </tr>
    <tr>
      <th>57</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
      <td>2016-04-02 13:49:14</td>
      <td>28.17</td>
      <td>3800595642657</td>
    </tr>
    <tr>
      <th>58</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
      <td>2016-10-19 20:25:16</td>
      <td>28.18</td>
      <td>6204409645686</td>
    </tr>
    <tr>
      <th>76</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
      <td>2016-07-24 15:18:57</td>
      <td>30.80</td>
      <td>3839329929610</td>
    </tr>
    <tr>
      <th>77</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
      <td>2016-03-06 18:21:13</td>
      <td>28.26</td>
      <td>3899054595030</td>
    </tr>
    <tr>
      <th>78</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
      <td>2016-09-18 18:24:17</td>
      <td>19.67</td>
      <td>2851656538564</td>
    </tr>
    <tr>
      <th>79</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
      <td>2016-01-03 11:35:45</td>
      <td>6.69</td>
      <td>7455207171412</td>
    </tr>
    <tr>
      <th>80</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
      <td>2016-09-25 16:35:54</td>
      <td>22.28</td>
      <td>9242784905015</td>
    </tr>
    <tr>
      <th>105</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
      <td>2016-09-05 05:20:39</td>
      <td>4.54</td>
      <td>9650770953139</td>
    </tr>
    <tr>
      <th>106</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
      <td>2016-11-21 10:41:56</td>
      <td>26.13</td>
      <td>6513545702246</td>
    </tr>
    <tr>
      <th>107</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
      <td>2016-05-22 21:34:07</td>
      <td>8.83</td>
      <td>5135321621391</td>
    </tr>
    <tr>
      <th>108</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
      <td>2016-10-07 11:09:50</td>
      <td>25.19</td>
      <td>7709877217148</td>
    </tr>
    <tr>
      <th>109</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
      <td>2016-06-11 21:01:35</td>
      <td>27.66</td>
      <td>6959463827218</td>
    </tr>
    <tr>
      <th>128</th>
      <td>South Josephville</td>
      <td>4</td>
      <td>Urban</td>
      <td>2016-06-01 05:15:38</td>
      <td>28.33</td>
      <td>7956832876432</td>
    </tr>
    <tr>
      <th>129</th>
      <td>South Josephville</td>
      <td>4</td>
      <td>Urban</td>
      <td>2016-10-06 03:53:57</td>
      <td>28.19</td>
      <td>2604125036913</td>
    </tr>
    <tr>
      <th>130</th>
      <td>South Josephville</td>
      <td>4</td>
      <td>Urban</td>
      <td>2016-03-11 23:05:39</td>
      <td>29.12</td>
      <td>7477161326509</td>
    </tr>
    <tr>
      <th>131</th>
      <td>South Josephville</td>
      <td>4</td>
      <td>Urban</td>
      <td>2016-03-24 18:38:25</td>
      <td>13.73</td>
      <td>1488440031973</td>
    </tr>
    <tr>
      <th>132</th>
      <td>South Josephville</td>
      <td>4</td>
      <td>Urban</td>
      <td>2016-08-28 04:52:03</td>
      <td>38.51</td>
      <td>4250063766740</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2355</th>
      <td>Stevensport</td>
      <td>6</td>
      <td>Rural</td>
      <td>2016-02-22 02:45:07</td>
      <td>19.91</td>
      <td>808097865942</td>
    </tr>
    <tr>
      <th>2356</th>
      <td>North Whitney</td>
      <td>10</td>
      <td>Rural</td>
      <td>2016-04-01 21:21:37</td>
      <td>51.01</td>
      <td>612689673941</td>
    </tr>
    <tr>
      <th>2357</th>
      <td>North Whitney</td>
      <td>10</td>
      <td>Rural</td>
      <td>2016-04-26 09:35:48</td>
      <td>42.09</td>
      <td>9465134041656</td>
    </tr>
    <tr>
      <th>2358</th>
      <td>North Whitney</td>
      <td>10</td>
      <td>Rural</td>
      <td>2016-06-24 21:09:09</td>
      <td>50.03</td>
      <td>9224879345166</td>
    </tr>
    <tr>
      <th>2359</th>
      <td>North Whitney</td>
      <td>10</td>
      <td>Rural</td>
      <td>2016-06-10 18:27:03</td>
      <td>29.25</td>
      <td>4071225680519</td>
    </tr>
    <tr>
      <th>2360</th>
      <td>North Whitney</td>
      <td>10</td>
      <td>Rural</td>
      <td>2016-02-21 18:20:14</td>
      <td>42.01</td>
      <td>3306522110065</td>
    </tr>
    <tr>
      <th>2366</th>
      <td>East Stephen</td>
      <td>6</td>
      <td>Rural</td>
      <td>2016-02-16 11:58:06</td>
      <td>22.43</td>
      <td>8118042484039</td>
    </tr>
    <tr>
      <th>2367</th>
      <td>East Stephen</td>
      <td>6</td>
      <td>Rural</td>
      <td>2016-07-27 09:55:18</td>
      <td>41.64</td>
      <td>3154261826545</td>
    </tr>
    <tr>
      <th>2368</th>
      <td>East Stephen</td>
      <td>6</td>
      <td>Rural</td>
      <td>2016-07-11 01:21:31</td>
      <td>41.86</td>
      <td>1023430862078</td>
    </tr>
    <tr>
      <th>2369</th>
      <td>East Stephen</td>
      <td>6</td>
      <td>Rural</td>
      <td>2016-11-19 04:47:01</td>
      <td>43.84</td>
      <td>7366535419230</td>
    </tr>
    <tr>
      <th>2370</th>
      <td>East Stephen</td>
      <td>6</td>
      <td>Rural</td>
      <td>2016-05-23 12:55:48</td>
      <td>48.49</td>
      <td>9985496304508</td>
    </tr>
    <tr>
      <th>2376</th>
      <td>East Leslie</td>
      <td>9</td>
      <td>Rural</td>
      <td>2016-04-21 18:44:59</td>
      <td>19.26</td>
      <td>5836114186294</td>
    </tr>
    <tr>
      <th>2377</th>
      <td>East Leslie</td>
      <td>9</td>
      <td>Rural</td>
      <td>2016-04-13 04:30:56</td>
      <td>40.47</td>
      <td>7075058703398</td>
    </tr>
    <tr>
      <th>2378</th>
      <td>East Leslie</td>
      <td>9</td>
      <td>Rural</td>
      <td>2016-04-26 02:34:30</td>
      <td>45.80</td>
      <td>9402873395510</td>
    </tr>
    <tr>
      <th>2379</th>
      <td>East Leslie</td>
      <td>9</td>
      <td>Rural</td>
      <td>2016-04-05 18:53:16</td>
      <td>44.78</td>
      <td>6113138249150</td>
    </tr>
    <tr>
      <th>2380</th>
      <td>East Leslie</td>
      <td>9</td>
      <td>Rural</td>
      <td>2016-11-13 10:21:10</td>
      <td>15.71</td>
      <td>7275986542384</td>
    </tr>
    <tr>
      <th>2387</th>
      <td>Hernandezshire</td>
      <td>10</td>
      <td>Rural</td>
      <td>2016-02-20 08:17:32</td>
      <td>58.95</td>
      <td>3176534714830</td>
    </tr>
    <tr>
      <th>2388</th>
      <td>Hernandezshire</td>
      <td>10</td>
      <td>Rural</td>
      <td>2016-06-26 20:11:50</td>
      <td>28.78</td>
      <td>6382848462030</td>
    </tr>
    <tr>
      <th>2389</th>
      <td>Hernandezshire</td>
      <td>10</td>
      <td>Rural</td>
      <td>2016-01-24 00:21:35</td>
      <td>30.32</td>
      <td>7342649945759</td>
    </tr>
    <tr>
      <th>2390</th>
      <td>Hernandezshire</td>
      <td>10</td>
      <td>Rural</td>
      <td>2016-03-05 10:40:16</td>
      <td>23.35</td>
      <td>7443355895137</td>
    </tr>
    <tr>
      <th>2391</th>
      <td>Hernandezshire</td>
      <td>10</td>
      <td>Rural</td>
      <td>2016-04-11 04:44:50</td>
      <td>10.41</td>
      <td>9823290002445</td>
    </tr>
    <tr>
      <th>2396</th>
      <td>Horneland</td>
      <td>8</td>
      <td>Rural</td>
      <td>2016-07-19 10:07:33</td>
      <td>12.63</td>
      <td>8214498891817</td>
    </tr>
    <tr>
      <th>2397</th>
      <td>Horneland</td>
      <td>8</td>
      <td>Rural</td>
      <td>2016-03-22 21:22:20</td>
      <td>31.53</td>
      <td>1797785685674</td>
    </tr>
    <tr>
      <th>2398</th>
      <td>Horneland</td>
      <td>8</td>
      <td>Rural</td>
      <td>2016-01-26 09:38:17</td>
      <td>21.73</td>
      <td>5665544449606</td>
    </tr>
    <tr>
      <th>2399</th>
      <td>Horneland</td>
      <td>8</td>
      <td>Rural</td>
      <td>2016-03-25 02:05:42</td>
      <td>20.04</td>
      <td>5729327140644</td>
    </tr>
    <tr>
      <th>2400</th>
      <td>West Kevintown</td>
      <td>5</td>
      <td>Rural</td>
      <td>2016-11-27 20:12:58</td>
      <td>12.92</td>
      <td>6460741616450</td>
    </tr>
    <tr>
      <th>2401</th>
      <td>West Kevintown</td>
      <td>5</td>
      <td>Rural</td>
      <td>2016-02-19 01:42:58</td>
      <td>11.15</td>
      <td>8622534016726</td>
    </tr>
    <tr>
      <th>2402</th>
      <td>West Kevintown</td>
      <td>5</td>
      <td>Rural</td>
      <td>2016-03-11 09:03:43</td>
      <td>42.13</td>
      <td>4568909568268</td>
    </tr>
    <tr>
      <th>2403</th>
      <td>West Kevintown</td>
      <td>5</td>
      <td>Rural</td>
      <td>2016-06-25 08:04:12</td>
      <td>24.53</td>
      <td>8188407925972</td>
    </tr>
    <tr>
      <th>2404</th>
      <td>West Kevintown</td>
      <td>5</td>
      <td>Rural</td>
      <td>2016-07-24 13:41:23</td>
      <td>11.78</td>
      <td>2001192693573</td>
    </tr>
  </tbody>
</table>
<p>618 rows × 6 columns</p>
</div>



## % of Total Fares by City Type


```python
# create table/get data
total_fares = combined_pd['fare'].sum()
percent_fares = (by_city['fare'].sum())/total_fares
percent_fares*100
```




    city
    Alvarezhaven            1.147054
    Alyssaberg              0.828603
    Anitamouth              0.519321
    Antoniomouth            0.803707
    Aprilchester            0.645826
    Arnoldview              1.203511
    Campbellport            0.781934
    Carrollbury             0.566051
    Carrollfort             1.138828
    Clarkstad               0.576195
    Conwaymouth             0.588395
    Davidtown               0.746168
    Davistown               0.831046
    East Cherylfurt         0.631538
    East Douglas            0.890255
    East Erin               1.059841
    East Jenniferchester    0.957783
    East Leslie             0.572561
    East Stephen            0.603889
    East Troybury           0.359847
    Edwardsbury             1.122128
    Erikport                0.371661
    Eriktown                0.748580
    Floresberg              0.499620
    Fosterside              0.854859
    Hernandezshire          0.445375
    Horneland               0.132876
    Jacksonfort             0.296958
    Jacobfort               1.187831
    Jasonfort               0.516444
                              ...   
    South Roy               0.885569
    South Shannonborough    0.615054
    Spencertown             0.952093
    Stevensport             0.247011
    Stewartview             1.002673
    Swansonbury             1.443966
    Thomastown              1.124803
    Tiffanyton              0.573117
    Torresshire             0.973247
    Travisville             0.968128
    Vickimouth              0.498105
    Webstertown             0.735343
    West Alexis             0.603781
    West Brandy             1.120674
    West Brittanyton        0.943990
    West Dawnfurt           1.001374
    West Evan               0.501259
    West Jefferyfurt        0.684299
    West Kevintown          0.233032
    West Oscar              1.088804
    West Pamelaborough      0.731709
    West Paulport           0.874807
    West Peter              1.192439
    West Sydneyhaven        0.622600
    West Tony               0.869936
    Williamchester          0.583060
    Williamshire            1.293817
    Wiseborough             0.666253
    Yolandafurt             0.841375
    Zimmermanmouth          1.050331
    Name: fare, Length: 125, dtype: float64




```python
urban_df = combined_pd[combined_pd['type']=='Urban'].groupby(['city'])['fare'].sum()

rural_df = combined_pd[combined_pd['type']=='Rural'].groupby(['city'])['fare'].sum()

suburban_df = combined_pd[combined_pd['type']=='Suburban'].groupby(['city'])['fare'].sum()

```


```python
# create labels, designate colors
community = ['Rural', 'Suburban', 'Urban']
percent_community = [rural_df.sum(), suburban_df.sum(), urban_df.sum()]
colors = ['gold', 'lightskyblue', 'lightcoral']
explode = [.5, 0, 0]

#chart effects
plt.pie(percent_community, explode=explode, labels=community, colors=colors, autopct="%1.1f%%", shadow=True, startangle=150)
plt.axis("equal")

# Set a Title
plt.title("% of Total Fares by City Type")
# Prints our pie chart to the screen
plt.show()
```


![png](output_23_0.png)


## % of Total Rides by City Type


```python
# create table/get data
total_rides = combined_pd['ride_id'].count()
percent_rides = (by_city['ride_id'].count())/total_rides
percent_rides*100
```




    city
    Alvarezhaven            1.287910
    Alyssaberg              1.080183
    Anitamouth              0.373909
    Antoniomouth            0.914001
    Aprilchester            0.789364
    Arnoldview              1.287910
    Campbellport            0.623182
    Carrollbury             0.415455
    Carrollfort             1.204819
    Clarkstad               0.498546
    Conwaymouth             0.457000
    Davidtown               0.872455
    Davistown               1.038637
    East Cherylfurt         0.540091
    East Douglas            0.914001
    East Erin               1.163274
    East Jenniferchester    0.789364
    East Leslie             0.457000
    East Stephen            0.415455
    East Troybury           0.290818
    Edwardsbury             1.121728
    Erikport                0.332364
    Eriktown                0.789364
    Floresberg              0.415455
    Fosterside              0.997092
    Hernandezshire          0.373909
    Horneland               0.166182
    Jacksonfort             0.249273
    Jacobfort               1.287910
    Jasonfort               0.498546
                              ...   
    South Roy               0.914001
    South Shannonborough    0.623182
    Spencertown             1.080183
    Stevensport             0.207727
    Stewartview             1.246365
    Swansonbury             1.412547
    Thomastown              0.997092
    Tiffanyton              0.540091
    Torresshire             1.080183
    Travisville             0.955546
    Vickimouth              0.623182
    Webstertown             0.664728
    West Alexis             0.830910
    West Brandy             1.246365
    West Brittanyton        0.997092
    West Dawnfurt           1.204819
    West Evan               0.498546
    West Jefferyfurt        0.872455
    West Kevintown          0.290818
    West Oscar              1.204819
    West Pamelaborough      0.581637
    West Paulport           0.706273
    West Peter              1.287910
    West Sydneyhaven        0.747819
    West Tony               0.789364
    Williamchester          0.457000
    Williamshire            1.287910
    Wiseborough             0.789364
    Yolandafurt             0.830910
    Zimmermanmouth          0.997092
    Name: ride_id, Length: 125, dtype: float64




```python
urban_df = combined_pd[combined_pd['type']=='Urban'].groupby(['city'])['ride_id'].count()

rural_df = combined_pd[combined_pd['type']=='Rural'].groupby(['city'])['ride_id'].count()

suburban_df = combined_pd[combined_pd['type']=='Suburban'].groupby(['city'])['ride_id'].count()

```


```python
# create labels, designate colors
community = ['Rural', 'Suburban', 'Urban']
percent_community = [rural_df.sum(), suburban_df.sum(), urban_df.sum()]
colors = ['gold', 'lightskyblue', 'lightcoral']
explode = [0, 0, 0.2]

#chart effects
plt.pie(percent_community, explode=explode, labels=community, colors=colors, autopct="%1.1f%%", shadow=True, startangle=150)
plt.axis("equal")
# Set a Title
plt.title("% of Total Rides by City Type")
# Prints our pie chart to the screen
plt.show()
```


![png](output_27_0.png)


## % of Total Drivers by City Type


```python
# # create table/get data
# drivers_by_type = by_type['driver_count'].first()
# total_drivers = drivers_by_type.sum()
# percent_drivers = drivers_by_type/total_drivers
# percent_drivers*100
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-22-f023a169e273> in <module>()
          1 # create table/get data
    ----> 2 drivers_by_type = by_type['driver_count'].first()
          3 total_drivers = drivers_by_type.sum()
          4 percent_drivers = drivers_by_type/total_drivers
          5 percent_drivers*100
    

    NameError: name 'by_type' is not defined



```python
urban_df = combined_pd[combined_pd['type']=='Urban'].groupby(['city'])['driver_count'].first()

rural_df = combined_pd[combined_pd['type']=='Rural'].groupby(['city'])['driver_count'].first()

suburban_df = combined_pd[combined_pd['type']=='Suburban'].groupby(['city'])['driver_count'].first()

```


```python
# create labels, designate colors
community = ['Rural', 'Suburban', 'Urban']
percent_community = [rural_df.sum(), suburban_df.sum(), urban_df.sum()]
colors = ['gold', 'lightskyblue', 'lightcoral']
explode = [0, 0.2, 0]

#chart effects
plt.pie(percent_community, explode=explode, labels=community, colors=colors, autopct="%1.1f%%", shadow=True, startangle=150)
plt.axis("equal")
# Set a Title
plt.title("% of Total Drivers by City Type")
# Prints our pie chart to the screen
plt.show()
```


![png](output_31_0.png)

